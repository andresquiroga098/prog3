/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carros;


public class Carros {
    
   String marca;
   int modelo;
   String color;
   double kilometraje;

    
    public static void main(String[] args) {
        
    }
    
}
